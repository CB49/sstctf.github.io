/**
 * Bishop piece for java
 */

public class Bishop extends Piece{

    public Bishop(int x, int y, boolean color){
        super(x, y, color);
    }

    @Override
    public int[][] ValidSquares(Tile[][] tiles){
        int[][] validSquares = new int[14][2];
        int i = 0;
            for(int t = 0; t<validSquares.length; t++){
                validSquares[t][0] = -1; validSquares[t][1] = -1;
            }
            while(true){
                for(int x=1; x<8; x++){
                    if(isValid(this.x+x, this.y+x) && tiles[this.x+x][this.y+x].getPiece() == null){
                        validSquares[i][0] = this.x+x; validSquares[i][1] = this.y+x;
                        i++;
                    } else if(isValid(this.x+x, this.y+x) && tiles[this.x+x][this.y+x].getPiece() != null){
                        if(tiles[this.x+x][this.y+x].getPiece().getColor() != this.getColor()){
                            validSquares[i][0] = this.x+x; validSquares[i][1] = this.y+x;
                            i++;
                        }
                        break;
                    } else {
                        break;
                    }
                }
                for(int x=1; x<8; x++){
                    if(isValid(this.x-x, this.y+x) && tiles[this.x-x][this.y+x].getPiece() == null){
                        validSquares[i][0] = this.x-x; validSquares[i][1] = this.y+x;
                        i++;
                    } else if(isValid(this.x-x, this.y+x) && tiles[this.x-x][this.y+x].getPiece() != null){
                        if(tiles[this.x-x][this.y+x].getPiece().getColor() != this.getColor()){
                            validSquares[i][0] = this.x-x; validSquares[i][1] = this.y+x;
                            i++;
                        }
                        break;
                    } else {
                        break;
                    }
                }
                for(int x=1; x<8; x++){
                    if(isValid(this.x+x, this.y-x) && tiles[this.x+x][this.y-x].getPiece() == null){
                        validSquares[i][0] = this.x+x; validSquares[i][1] = this.y-x;
                        i++;
                    } else if(isValid(this.x+x, this.y-x) && tiles[this.x+x][this.y-x].getPiece() != null){
                        if(tiles[this.x+x][this.y-x].getPiece().getColor() != this.getColor()){
                            validSquares[i][0] = this.x+x; validSquares[i][1] = this.y-x;
                            i++;
                        }
                        break;
                    } else {
                        break;
                    }
                }
                for(int x=1; x<8; x++){
                    if(isValid(this.x-x, this.y-x) && tiles[this.x-x][this.y-x].getPiece() == null){
                        validSquares[i][0] = this.x-x; validSquares[i][1] = this.y-x;
                        i++;
                    } else if(isValid(this.x-x, this.y-x) && tiles[this.x-x][this.y-x].getPiece() != null){
                        if(tiles[this.x-x][this.y-x].getPiece().getColor() != this.getColor()){
                            validSquares[i][0] = this.x-x; validSquares[i][1] = this.y-x;
                            i++;
                        }
                        break;
                    } else {
                        break;
                    }
                }
                break;
            }
        return validSquares;
    }

    @Override
    public String getAbbr(){
        return "B";
    }

    @Override
    public String getName(){
        return "bishop";
    }
}